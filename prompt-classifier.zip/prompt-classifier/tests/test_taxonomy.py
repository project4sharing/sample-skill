from pathlib import Path

import pytest

from prompt_classifier import TaxonomyError, load_taxonomy
from prompt_classifier.taxonomy import parse_taxonomy

SKILL_DIR = Path(__file__).resolve().parents[1] / "skills" / "prompt-classifier"


def test_bundled_skill_parses():
    tax = load_taxonomy(SKILL_DIR)
    assert tax.skill_name == "prompt-classifier"
    assert tax.codes == [
        "CODE", "DATA_ANALYSIS", "MATH_REASONING", "TEXT_TRANSFORMATION", "WRITING",
        "ADVICE", "IDEATION", "FACTUAL_QA", "CONVERSATION", "OTHER",
    ]
    assert all(c.definition for c in tax.categories)
    assert tax.skills_root == SKILL_DIR.parent


def _doc(categories: str) -> str:
    return f"---\nname: t\ndescription: d\n---\n# T\n## Categories\n{categories}\n## Output contract\nx\n"


def test_rejects_bad_code():
    with pytest.raises(TaxonomyError, match="UPPER_SNAKE_CASE"):
        parse_taxonomy(_doc("### Bad Name\n**Definition:** x\n\n### OK\n**Definition:** y\n"), Path("s/t/SKILL.md"))


def test_rejects_missing_definition():
    with pytest.raises(TaxonomyError, match="Definition"):
        parse_taxonomy(_doc("### A\nnothing\n\n### B\n**Definition:** y\n"), Path("s/t/SKILL.md"))


def test_rejects_duplicates_and_too_few():
    with pytest.raises(TaxonomyError, match="Duplicate"):
        parse_taxonomy(_doc("### A\n**Definition:** x\n\n### A\n**Definition:** y\n"), Path("s/t/SKILL.md"))
    with pytest.raises(TaxonomyError, match="at least two"):
        parse_taxonomy(_doc("### A\n**Definition:** x\n"), Path("s/t/SKILL.md"))


def test_section_stops_at_next_h2():
    tax = parse_taxonomy(_doc("### A\n**Definition:** x\n\n### B\n**Definition:** y\n"), Path("s/t/SKILL.md"))
    assert tax.codes == ["A", "B"]
