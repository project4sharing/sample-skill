"""End-to-end example: classify a pandas DataFrame of prompts with Copilot.

Run from the project root after `pip install -e .` and `copilot` login:

    python examples/classify_dataframe.py
"""

import asyncio
import logging

import pandas as pd

from prompt_classifier import ClassifierConfig, PromptClassifier

logging.basicConfig(level=logging.WARNING)


async def main() -> None:
    df = pd.DataFrame(
        {
            "prompt": [
                "Write a Python function that removes duplicates from a list",
                "Draft a LinkedIn post announcing our new product",
                "What is the capital of Australia?",
                "I'm torn between studying law or medicine, what should I do?",
                "Brainstorm themes for a company offsite",
                "Summarise this: The meeting moved to Thursday; Ana owns the budget.",
                "What's 17% of 2,450?",
                "thanks!",
            ]
        }
    )

    config = ClassifierConfig(
        model=None,          # e.g. "gpt-5" or "claude-sonnet-4.5"; None = Copilot default
        batch_size=10,
        max_concurrency=4,
    )

    async with PromptClassifier(config=config) as clf:
        print("Categories:", ", ".join(clf.taxonomy.codes))
        result = await clf.classify_dataframe(df, column="prompt")

    pd.set_option("display.max_colwidth", 60)
    print(result[["prompt", "category", "confidence", "rationale"]])
    print("\nCounts:\n", result["category"].value_counts())


if __name__ == "__main__":
    asyncio.run(main())

# In a Jupyter notebook, skip asyncio.run and just do:
#   from prompt_classifier import classify_dataframe_async
#   df = await classify_dataframe_async(df, column="prompt")
