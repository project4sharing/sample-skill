# prompt-classifier

Classify a pandas DataFrame of prompts into a **strict, fixed set of categories**
using a **Copilot skill** and the **GitHub Copilot SDK** (`github-copilot-sdk`).

```
prompt-classifier/
├── skills/
│   └── prompt-classifier/
│       └── SKILL.md            ← the skill: categories, definitions, rules, output contract
├── src/prompt_classifier/
│   ├── taxonomy.py             ← parses the category codes/definitions out of SKILL.md
│   ├── classifier.py           ← Copilot SDK classifier (batching, retries, DataFrame API)
│   └── cli.py                  ← `prompt-classify` command for CSV/Parquet/XLSX/JSONL
├── examples/classify_dataframe.py
├── data/sample_prompts.csv
└── tests/                      ← offline tests using a fake Copilot client
```

## How it works

1. **SKILL.md is the single source of truth.** It holds the categories (each with
   Definition / Includes / Excludes / Examples), a tie-break order, and the JSON output
   contract. Python parses the same file, so labels in code and in the prompt can't drift.
2. **The skill is loaded with the SDK** via `skill_directories=["skills"]` and
   **eagerly preloaded** into a dedicated custom agent (`custom_agents=[{"skills": ["prompt-classifier"], "tools": []}]`),
   so the model always has the full taxonomy in context.
3. **Strict labels.** Replies go through `session.send_and_wait_typed(...)` with a Pydantic
   schema whose `category` field is a `Literal[...]` of exactly the codes in SKILL.md.
   An invalid label fails validation and the batch is retried.
4. **Locked down.** The agent has no tools, every permission request is rejected, repo
   custom-instructions discovery is off, and prompts are sent as escaped JSON data —
   so a prompt like *"ignore previous instructions…"* just gets classified.
5. **Efficient.** Prompts are batched (default 10/call), batches run concurrently
   (default 4), identical prompts are classified once, blank rows are skipped.
   Each batch gets a fresh session; items missing from a reply are retried one by one.

## Setup

Requires Python 3.11+, the GitHub Copilot CLI, and a Copilot subscription.

```bash
# 1. Install and log in to the Copilot CLI (the SDK talks to it over JSON-RPC)
npm install -g @github/copilot
copilot          # then run /login once

# 2. Install this project
cd prompt-classifier
pip install -e ".[progress,dev]"
```

For CI/servers you can authenticate with a token instead:
`PromptClassifier(client_kwargs={"github_token": os.environ["GH_TOKEN"]})`.

## Usage

### From Python (script)

```python
import pandas as pd
from prompt_classifier import classify_dataframe, ClassifierConfig

df = pd.read_csv("data/sample_prompts.csv")
out = classify_dataframe(df, column="prompt",
                         config=ClassifierConfig(model="gpt-5", batch_size=10))
print(out[["prompt", "category", "confidence", "rationale"]])
```

### From Jupyter (an event loop is already running)

```python
from prompt_classifier import classify_dataframe_async
out = await classify_dataframe_async(df, column="prompt")
```

### Reusing one client for many DataFrames

```python
from prompt_classifier import PromptClassifier, ClassifierConfig

async with PromptClassifier(config=ClassifierConfig(max_concurrency=8)) as clf:
    a = await clf.classify_dataframe(df_a, "prompt")
    b = await clf.classify_dataframe(df_b, "text", prefix="intent_")
```

### Command line

```bash
prompt-classify --show-taxonomy
prompt-classify data/sample_prompts.csv -o classified.csv --column prompt --model gpt-5
```

### Output columns

| column | meaning |
|---|---|
| `category` | one code from SKILL.md, or `<NA>` if the row failed / was blank |
| `confidence` | 0–1, model's self-reported confidence (clamped) |
| `rationale` | one-sentence reason (≤ 25 words) |
| `classify_error` | `<NA>` on success; otherwise why it failed (e.g. `empty prompt`) |

Use `prefix="xyz_"` to namespace the columns.

## Customising the categories

Edit `skills/prompt-classifier/SKILL.md` — no Python changes needed. Rules the parser enforces:

- Categories live under a `## Categories` heading and end at the next `##` heading.
- Each category is a `### CODE_NAME` heading in `UPPER_SNAKE_CASE`.
- Each category has a `**Definition:**` paragraph (Includes/Excludes/Examples are optional but strongly recommended).
- At least two categories; codes must be unique.

Also update the **tie-break order** line and the example in the **Output contract**
so they only mention your codes. Run `prompt-classify --show-taxonomy` and `pytest`
(update the expected codes in `tests/test_taxonomy.py`) to confirm it parses.

To keep several taxonomies, copy the folder (e.g. `skills/support-ticket-classifier/`,
with its own `name:` in the frontmatter) and pass `skill_dir=` to `PromptClassifier`.

## Tuning

| `ClassifierConfig` field | default | notes |
|---|---|---|
| `model` | Copilot default | e.g. `"gpt-5"`, `"claude-sonnet-4.5"` — whatever your plan offers |
| `batch_size` | 10 | 1 = most accurate & most expensive; 20+ is cheaper but more drift |
| `max_concurrency` | 4 | parallel batches; lower it if you hit rate limits |
| `max_retries` | 3 | per batch, with exponential backoff |
| `timeout` | 180 s | per batch |
| `max_prompt_chars` | 4000 | long prompts are truncated (head + tail) |
| `structured_output` | True | auto-falls back to JSON-in-text if the model rejects schemas |
| `reasoning_effort` | None | `"low"` is usually enough for classification and is faster |
| `deduplicate` | True | identical prompt text is classified once |

**Validate before trusting at scale:** hand-label ~100 rows, run the classifier, and
check agreement (`pd.crosstab(df.gold, df.category)`). Disagreements usually point to a
definition or Excludes line in SKILL.md that needs tightening.

## Tests

```bash
pytest
```

The tests use a fake Copilot client, so they run offline and cover batching, ordering,
deduplication, blank rows, schema enforcement, retries of missing ids, the JSON-text
fallback, and prompt-injection escaping.
