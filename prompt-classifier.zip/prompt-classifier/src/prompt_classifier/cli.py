"""Command line entry point: classify a CSV / Parquet / Excel / JSONL file of prompts.

    prompt-classify data/sample_prompts.csv -o out.csv --column prompt --model gpt-5
    prompt-classify --show-taxonomy
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import sys
from pathlib import Path

import pandas as pd

from .classifier import DEFAULT_SKILL_DIR, ClassifierConfig, PromptClassifier
from .taxonomy import load_taxonomy


def _read(path: Path) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        return pd.read_parquet(path)
    if suffix in {".xlsx", ".xls"}:
        return pd.read_excel(path)
    if suffix in {".jsonl", ".ndjson"}:
        return pd.read_json(path, lines=True)
    if suffix == ".json":
        return pd.read_json(path)
    return pd.read_csv(path)


def _write(df: pd.DataFrame, path: Path) -> None:
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        df.to_parquet(path, index=False)
    elif suffix in {".xlsx", ".xls"}:
        df.to_excel(path, index=False)
    elif suffix in {".jsonl", ".ndjson"}:
        df.to_json(path, orient="records", lines=True, force_ascii=False)
    else:
        df.to_csv(path, index=False)


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("input", nargs="?", type=Path, help="CSV/Parquet/XLSX/JSONL file")
    p.add_argument("-o", "--output", type=Path, help="Output file (default: <input>.classified.csv)")
    p.add_argument("-c", "--column", default="prompt", help="Column holding the prompt text")
    p.add_argument("--skill-dir", type=Path, default=DEFAULT_SKILL_DIR)
    p.add_argument("--model", default=None, help="Copilot model id; default = Copilot default")
    p.add_argument("--batch-size", type=int, default=10)
    p.add_argument("--concurrency", type=int, default=4)
    p.add_argument("--limit", type=int, default=None, help="Only classify the first N rows")
    p.add_argument("--no-structured", action="store_true", help="Disable schema-enforced output")
    p.add_argument("--show-taxonomy", action="store_true", help="Print parsed categories and exit")
    p.add_argument("-v", "--verbose", action="store_true")
    args = p.parse_args(argv)

    logging.basicConfig(level=logging.INFO if args.verbose else logging.WARNING,
                        format="%(levelname)s %(name)s: %(message)s")

    if args.show_taxonomy:
        tax = load_taxonomy(args.skill_dir)
        print(f"Skill: {tax.skill_name}  ({tax.skill_file})")
        for cat in tax.categories:
            print(f"- {cat.code}: {cat.definition}")
        return 0

    if args.input is None:
        p.error("input file is required (or use --show-taxonomy)")

    df = _read(args.input)
    if args.limit:
        df = df.head(args.limit)
    config = ClassifierConfig(
        model=args.model,
        batch_size=args.batch_size,
        max_concurrency=args.concurrency,
        structured_output=not args.no_structured,
    )

    async def run() -> pd.DataFrame:
        async with PromptClassifier(args.skill_dir, config) as clf:
            return await clf.classify_dataframe(df, column=args.column)

    out = asyncio.run(run())
    output = args.output or args.input.with_suffix(".classified.csv")
    _write(out, output)

    print(f"Wrote {len(out)} rows to {output}")
    print(out["category"].value_counts(dropna=False).to_string())
    errors = out["classify_error"].notna().sum()
    if errors:
        print(f"{errors} row(s) failed; see the classify_error column.", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
