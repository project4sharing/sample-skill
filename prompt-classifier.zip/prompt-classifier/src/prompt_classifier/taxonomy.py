"""Load the category taxonomy from the skill's SKILL.md.

SKILL.md is the single source of truth: the model reads it as a skill, and this
module parses the same file so Python knows the exact set of allowed labels
(used to build the structured-output schema and to validate answers).

Expected layout inside SKILL.md::

    ## Categories

    ### CATEGORY_CODE
    **Definition:** one paragraph ...
    (any further markdown: Includes / Excludes / Examples)

    ### NEXT_CODE
    ...

    ## <next level-2 heading ends the categories section>
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

CODE_PATTERN = re.compile(r"^[A-Z][A-Z0-9_]*$")
_FRONTMATTER = re.compile(r"\A---\s*\n(.*?)\n---\s*\n", re.DOTALL)
_DEFINITION = re.compile(r"\*\*Definition:\*\*\s*(.+?)(?:\n\s*\n|\Z)", re.DOTALL)


class TaxonomyError(ValueError):
    """Raised when SKILL.md does not describe a valid taxonomy."""


@dataclass(frozen=True)
class Category:
    code: str
    definition: str
    body: str


@dataclass(frozen=True)
class Taxonomy:
    skill_name: str
    description: str
    categories: tuple[Category, ...]
    skill_file: Path

    @property
    def codes(self) -> list[str]:
        return [c.code for c in self.categories]

    @property
    def skill_dir(self) -> Path:
        """Directory that contains SKILL.md (e.g. skills/prompt-classifier)."""
        return self.skill_file.parent

    @property
    def skills_root(self) -> Path:
        """Parent folder passed to the SDK's ``skill_directories`` (e.g. skills/)."""
        return self.skill_file.parent.parent

    def definitions(self) -> dict[str, str]:
        return {c.code: c.definition for c in self.categories}


def _parse_frontmatter(text: str) -> tuple[dict[str, str], str]:
    match = _FRONTMATTER.match(text)
    if not match:
        return {}, text
    meta: dict[str, str] = {}
    for line in match.group(1).splitlines():
        if ":" in line and not line.lstrip().startswith("#"):
            key, value = line.split(":", 1)
            meta[key.strip()] = value.strip().strip("'\"")
    return meta, text[match.end():]


def _categories_section(body: str) -> str:
    lines = body.splitlines()
    start = None
    for i, line in enumerate(lines):
        if re.match(r"^##\s+Categories\s*$", line.strip(), re.IGNORECASE):
            start = i + 1
            break
    if start is None:
        raise TaxonomyError("SKILL.md has no '## Categories' section.")
    end = len(lines)
    for j in range(start, len(lines)):
        if re.match(r"^##\s+\S", lines[j]) and not lines[j].startswith("###"):
            end = j
            break
    return "\n".join(lines[start:end])


def parse_taxonomy(text: str, skill_file: Path) -> Taxonomy:
    meta, body = _parse_frontmatter(text)
    section = _categories_section(body)

    parts = re.split(r"^###\s+(.+?)\s*$", section, flags=re.MULTILINE)
    # parts = [preamble, heading1, body1, heading2, body2, ...]
    categories: list[Category] = []
    seen: set[str] = set()
    for heading, cat_body in zip(parts[1::2], parts[2::2]):
        code = heading.strip().strip("`").strip()
        if not CODE_PATTERN.match(code):
            raise TaxonomyError(
                f"Category heading '{heading}' must be an UPPER_SNAKE_CASE code."
            )
        if code in seen:
            raise TaxonomyError(f"Duplicate category code: {code}")
        seen.add(code)
        match = _DEFINITION.search(cat_body)
        if not match:
            raise TaxonomyError(f"Category {code} is missing a '**Definition:**' line.")
        definition = " ".join(match.group(1).split())
        categories.append(Category(code=code, definition=definition, body=cat_body.strip()))

    if len(categories) < 2:
        raise TaxonomyError("A taxonomy needs at least two categories.")

    return Taxonomy(
        skill_name=meta.get("name") or skill_file.parent.name,
        description=meta.get("description", ""),
        categories=tuple(categories),
        skill_file=skill_file,
    )


def load_taxonomy(skill_path: str | Path) -> Taxonomy:
    """Load a taxonomy from a skill directory or a SKILL.md path."""
    path = Path(skill_path).expanduser().resolve()
    skill_file = path / "SKILL.md" if path.is_dir() else path
    if not skill_file.is_file():
        raise TaxonomyError(f"SKILL.md not found at {skill_file}")
    return parse_taxonomy(skill_file.read_text(encoding="utf-8"), skill_file)
