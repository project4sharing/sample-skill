"""Classify prompts into a strict taxonomy using a Copilot SDK skill."""

from .classifier import (
    ClassificationResult,
    ClassifierConfig,
    PromptClassifier,
    classify_dataframe,
    classify_dataframe_async,
)
from .taxonomy import Category, Taxonomy, TaxonomyError, load_taxonomy

__all__ = [
    "Category",
    "ClassificationResult",
    "ClassifierConfig",
    "PromptClassifier",
    "Taxonomy",
    "TaxonomyError",
    "classify_dataframe",
    "classify_dataframe_async",
    "load_taxonomy",
]
